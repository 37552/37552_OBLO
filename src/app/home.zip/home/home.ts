import { ChangeDetectionStrategy, Component, signal, OnInit, input, output } from '@angular/core';
import { CommonModule, NgClass } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [CommonModule],
  templateUrl: './home.html',
  styleUrl: './home.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Home {
  sessionstorageUserRole = sessionStorage.getItem('userRole') || '';
  userRole = this.sessionstorageUserRole.toUpperCase();
}
